from util.BSSQLUtil import *
from util.BaseStationTransfer import *
import pandas as pd
import numpy as np

if __name__ == '__main__':
    with open("result2.txt", 'a') as file:
        file.write('result')
        file.write('\n')
        file.close()
