class BaseStation():
    def __init__(self):
        self.id = None
        self.global_computing_resource = None
        self.reserved_computing_resource = None
        self.vehicle_density = None
        self.computing_efficiency = None
        self.completion_ratio = None
        self.total_received_task = None
        self.reliability = None



