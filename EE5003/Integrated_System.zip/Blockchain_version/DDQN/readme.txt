1. test whether the database has changed or whether the change is right. Pay more attention to the id of changed data.
2. initialize the data（ok）
3. when the database is updated, send message to us and then the agent can go on next stage.
4. pay attention to the data type of the database(ok)
5.The probability of base station 0 and base station 1 is nearly the same. Now we are supposed to control
more data as constant to check whether the reinforcemnt learning can choose the better base station as the target.