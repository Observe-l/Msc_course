OMNeT++ Version: 5.6.1
SUMO Version: latest
Veins: 5.1 (based on your OMNeT++ version) 